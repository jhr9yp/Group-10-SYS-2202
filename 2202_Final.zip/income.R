library(DBI)
library(RMySQL)
library(ggplot2)
library(dplyr)


#making a new data table based only on income from 2015, 2016, and the state
income2015 <- income$`2015`
income2016 <- income$`2016`
state <- income$State

income_clean <- data.frame(state, income2015, income2016)

#removeing all non-states
income_clean <- income_clean %>% filter(state != "United States" & state != "D.C.")

# finding the percent change between the years and rounding
income_clean <- income_clean %>%
  arrange(state, .by_group = TRUE) %>%
  mutate(pct_change = ((income2016-income2015)/income2015))
income_clean$pct_change <- round(income_clean$pct_change,digits=5)

#finding the average income between 2015 and 2016
income_clean$incomeAvg <- rowMeans(income_clean[c('income2015', 'income2016')], na.rm=TRUE)

#renaming columns
names(income_clean) <- c("Location", "Avg Income (2015)", "Avg Income (2016)", "Income Rate Change", "Average Income")

View(income_clean)


