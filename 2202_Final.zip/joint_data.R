library(DBI)
library(RMySQL)
library(ggplot2)
library(ggmap)
library(maptools)
library(maps)
library(lubridate)
library(dplyr)
library(stringr)
library(stringi)

#PUTTING ALL DATA INTO ONE TABLE (obesity, fast food count, income)
df_final <- data.frame(income_clean$Location, income_clean$`Avg Income (2015)`, income_clean$`Avg Income (2016)`,
                       income_clean$`Income Rate Change`, income_clean$`Average Income`,
                       obesity_clean_final$`Avg Obesity Rate (2015)`, obesity_clean_final$`Avg Obesity Rate (2016)`,
                       obesity_clean_final$`Obesity Rate Change`, obesity_clean_final$`Average Obesity`,
                       food_clean_final$`Fast Food Count (2015)`, food_clean_final$`Fast Food Count (2016)`,
                       food_clean_final$`Fast Food Count Increase`, food_clean_final$`Average Fast Food Count`)

names(df_final) <- c("Location", "Avg Income (2015)", "Avg Income (2016)", "Income Rate Change", "Avg Income", 
                     "Avg Obesity Rate (2015)", "Avg Obesity Rate (2016)", "Obesity Rate Change", "Avg Obesity",
                     "Fast Food Count (2015)", "Fast Food Count (2016)", "Fast Food Count Increase", "Avg Fast Food Count")
View(df_final)


#plotting average obesity and fast food data
ggplot(data=df_final, (aes(x=`Avg Obesity`, y=`Avg Fast Food Count`))) + geom_point()

#plotting average obesity and income
ggplot(data=df_final, (aes(x=`Avg Obesity`, y=`Avg Income`))) + geom_point()

#plotting average income and fast food count
ggplot(data=df_final, (aes(x=`Avg Income`, y=`Avg Fast Food Count`))) + geom_point()

#plotting all three variables, with the color of the data points representing fast food count
ggplot(data=df_final, (aes(x=`Avg Obesity`, y=`Avg Income`, color = `Avg Fast Food Count`))) + geom_point()

